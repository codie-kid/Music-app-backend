package music_app_backend.service;

import music_app_backend.model.Playlist;
import music_app_backend.model.Song;
import music_app_backend.model.User;
import music_app_backend.repository.PlaylistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PlaylistService {
    @Autowired
    private PlaylistRepository playlistRepository;

    @Autowired
    private SongService songService;

    public Playlist createPlaylist(Playlist playlist, Long userId) {
        // Set user for the playlist
        User user = new User();
        user.setId(userId);
        playlist.setUser(user);

        return playlistRepository.save(playlist);
    }

    public List<Playlist> getUserPlaylists(Long userId) {
        return playlistRepository.findByUserId(userId);
    }

    public Playlist addSongToPlaylist(Long playlistId, Long songId, Long userId) {
        Playlist playlist = playlistRepository.findByIdAndUserId(playlistId, userId)
                .orElseThrow(() -> new RuntimeException("Playlist not found"));

        Song song = songService.getSongById(songId)
                .orElseThrow(() -> new RuntimeException("Song not found"));

        playlist.getSongs().add(song);
        return playlistRepository.save(playlist);
    }

    public Playlist removeSongFromPlaylist(Long playlistId, Long songId, Long userId) {
        Playlist playlist = playlistRepository.findByIdAndUserId(playlistId, userId)
                .orElseThrow(() -> new RuntimeException("Playlist not found"));

        playlist.setSongs(
                playlist.getSongs().stream()
                        .filter(song -> !song.getId().equals(songId))
                        .collect(Collectors.toList())
        );

        return playlistRepository.save(playlist);
    }
}
