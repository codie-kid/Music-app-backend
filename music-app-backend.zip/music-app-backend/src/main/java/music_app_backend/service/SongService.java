package music_app_backend.service;

import music_app_backend.model.Song;
import music_app_backend.repository.SongRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SongService {
    @Autowired
    private SongRepository songRepository;

    public Song addSong(Song song) {
        return songRepository.save(song);
    }

    public List<Song> getAllSongs() {
        return songRepository.findAll();
    }

    public Optional<Song> getSongById(Long id) {
        return songRepository.findById(id);
    }

    public List<Song> searchSongs(String keyword) {
        List<Song> results = new ArrayList<>();
        results.addAll(songRepository.findByTitleContainingIgnoreCase(keyword));
        results.addAll(songRepository.findByArtistContainingIgnoreCase(keyword));
        results.addAll(songRepository.findByGenreContainingIgnoreCase(keyword));

        // Remove duplicates
        return results.stream()
                .distinct()
                .collect(Collectors.toList());
    }

}

