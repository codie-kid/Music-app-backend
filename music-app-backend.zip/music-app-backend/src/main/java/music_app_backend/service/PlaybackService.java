package music_app_backend.service;

import music_app_backend.model.PlaybackState;
import music_app_backend.model.Song;
import music_app_backend.model.User;
import music_app_backend.repository.PlaybackStateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlaybackService {
    @Autowired
    private PlaybackStateRepository playbackStateRepository;

    @Autowired
    private SongService songService;

    public PlaybackState playSong(Long userId, Long songId) {
        Song song = songService.getSongById(songId)
                .orElseThrow(() -> new RuntimeException("Song not found"));

        PlaybackState playbackState = playbackStateRepository.findByUserId(userId)
                .orElse(new PlaybackState());

        playbackState.setUser(new User(userId));
        playbackState.setSong(song);
        playbackState.setCurrentPosition(0);
        playbackState.setStatus("PLAYING");

        return playbackStateRepository.save(playbackState);
    }

    public PlaybackState pauseSong(Long userId) {
        PlaybackState playbackState = playbackStateRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("No active playback"));

        if ("PLAYING".equals(playbackState.getStatus())) {
            playbackState.setStatus("PAUSED");
            return playbackStateRepository.save(playbackState);
        }

        return playbackState;
    }

    public PlaybackState resumeSong(Long userId) {
        PlaybackState playbackState = playbackStateRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("No active playback"));

        if ("PAUSED".equals(playbackState.getStatus())) {
            playbackState.setStatus("PLAYING");
            return playbackStateRepository.save(playbackState);
        }

        return playbackState;
    }

    public void stopSong(Long userId) {
        PlaybackState playbackState = playbackStateRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("No active playback"));

        playbackState.setStatus("STOPPED");
        playbackStateRepository.save(playbackState);
    }

    public PlaybackState getCurrentPlayback(Long userId) {
        return playbackStateRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("No active playback"));
    }
}
