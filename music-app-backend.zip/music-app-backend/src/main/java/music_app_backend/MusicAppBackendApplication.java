package music_app_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicAppBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicAppBackendApplication.class, args);
	}

}
