package music_app_backend.config;



import music_app_backend.model.Song;
import music_app_backend.model.User;
import music_app_backend.repository.SongRepository;
import music_app_backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SongRepository songRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Only initialize if no users exist
        if (userRepository.count() == 0) {
            // Create admin user
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setEmail("admin@musicapp.com");
            admin.setRole("ADMIN");

            // Create regular user
            User user = new User();
            user.setUsername("user1");
            user.setPassword(passwordEncoder.encode("password123"));
            user.setEmail("user1@musicapp.com");
            user.setRole("USER");

            userRepository.saveAll(Arrays.asList(admin, user));

            // Create sample songs
            Song song1 = new Song();
            song1.setTitle("Bohemian Rhapsody");
            song1.setArtist("Queen");
            song1.setGenre("Rock");
            song1.setDuration(355);
            song1.setFilePath("/songs/queen_bohemian_rhapsody.mp3");

            Song song2 = new Song();
            song2.setTitle("Hotel California");
            song2.setArtist("Eagles");
            song2.setGenre("Rock");
            song2.setDuration(390);
            song2.setFilePath("/songs/eagles_hotel_california.mp3");

            Song song3 = new Song();
            song3.setTitle("Blinding Lights");
            song3.setArtist("The Weeknd");
            song3.setGenre("Pop");
            song3.setDuration(200);
            song3.setFilePath("/songs/weeknd_blinding_lights.mp3");

            Song song4 = new Song();
            song4.setTitle("Shape of You");
            song4.setArtist("Ed Sheeran");
            song4.setGenre("Pop");
            song4.setDuration(233);
            song4.setFilePath("/songs/ed_sheeran_shape_of_you.mp3");

            Song song5 = new Song();
            song5.setTitle("Uptown Funk");
            song5.setArtist("Mark Ronson ft. Bruno Mars");
            song5.setGenre("Funk");
            song5.setDuration(270);
            song5.setFilePath("/songs/ronson_uptown_funk.mp3");

            songRepository.saveAll(Arrays.asList(song1, song2, song3, song4, song5));

            System.out.println("Sample data initialized successfully!");
        }
    }
}
