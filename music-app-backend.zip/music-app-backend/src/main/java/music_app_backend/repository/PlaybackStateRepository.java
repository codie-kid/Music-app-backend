package music_app_backend.repository;

import music_app_backend.model.PlaybackState;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PlaybackStateRepository extends JpaRepository<PlaybackState, Long> {
    Optional<PlaybackState> findByUserId(Long userId);
}
