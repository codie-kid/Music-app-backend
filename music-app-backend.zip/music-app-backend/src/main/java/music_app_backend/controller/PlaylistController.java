package music_app_backend.controller;

import music_app_backend.model.Playlist;
import music_app_backend.model.User;
import music_app_backend.service.PlaylistService;
import music_app_backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/playlists")
public class PlaylistController {
    @Autowired
    private PlaylistService playlistService;

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<?> createPlaylist(@RequestBody Playlist playlist, Principal principal) {
        try {
            User user = userService.getUserProfile(principal.getName());
            Playlist newPlaylist = playlistService.createPlaylist(playlist, user.getId());
            return ResponseEntity.ok(newPlaylist);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<?> getUserPlaylists(Principal principal) {
        try {
            User user = userService.getUserProfile(principal.getName());
            List<Playlist> playlists = playlistService.getUserPlaylists(user.getId());
            return ResponseEntity.ok(playlists);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/{playlistId}/songs/{songId}")
    public ResponseEntity<?> addSongToPlaylist(@PathVariable Long playlistId,
            @PathVariable Long songId,
            Principal principal) {
        try {
            User user = userService.getUserProfile(principal.getName());
            Playlist playlist = playlistService.addSongToPlaylist(playlistId, songId, user.getId());
            return ResponseEntity.ok(playlist);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{playlistId}/songs/{songId}")
    public ResponseEntity<?> removeSongFromPlaylist(@PathVariable Long playlistId,
            @PathVariable Long songId,
            Principal principal) {
        try {
            User user = userService.getUserProfile(principal.getName());
            Playlist playlist = playlistService.removeSongFromPlaylist(playlistId, songId, user.getId());
            return ResponseEntity.ok(playlist);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}

