package music_app_backend.controller;

import music_app_backend.model.PlaybackState;
import music_app_backend.model.User;
import music_app_backend.service.PlaybackService;
import music_app_backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

@RestController
@RequestMapping("/api/playback")
public class PlaybackController {
    @Autowired
    private PlaybackService playbackService;

    @Autowired
    private UserService userService;

    @PostMapping("/play/{songId}")
    public ResponseEntity<?> playSong(@PathVariable Long songId, Principal principal) {
        try {
            User user = userService.getUserProfile(principal.getName());
            PlaybackState playbackState = playbackService.playSong(user.getId(), songId);
            return ResponseEntity.ok(playbackState);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/pause")
    public ResponseEntity<?> pauseSong(Principal principal) {
        try {
            User user = userService.getUserProfile(principal.getName());
            PlaybackState playbackState = playbackService.pauseSong(user.getId());
            return ResponseEntity.ok(playbackState);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/resume")
    public ResponseEntity<?> resumeSong(Principal principal) {
        try {
            User user = userService.getUserProfile(principal.getName());
            PlaybackState playbackState = playbackService.resumeSong(user.getId());
            return ResponseEntity.ok(playbackState);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/stop")
    public ResponseEntity<?> stopSong(Principal principal) {
        try {
            User user = userService.getUserProfile(principal.getName());
            playbackService.stopSong(user.getId());
            return ResponseEntity.ok("Playback stopped");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/current")
    public ResponseEntity<?> getCurrentPlayback(Principal principal) {
        try {
            User user = userService.getUserProfile(principal.getName());
            PlaybackState playbackState = playbackService.getCurrentPlayback(user.getId());
            return ResponseEntity.ok(playbackState);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
